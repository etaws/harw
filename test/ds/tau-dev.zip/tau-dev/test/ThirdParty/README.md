# ThirdParty Tests

This section contains actual real-world code written by some amazing people. We will use their code as a way to test out Tau's
capabilities. 

Tau **does not** own/maintain any of these projects. All LICENSE and Copyright information will be retained and are subject to the owner(s) of the respective projects. 