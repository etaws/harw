#include <tau/tau.h>
TAU_MAIN()