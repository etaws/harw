# Tau's Internal Tests
This contains all the tests that Tau uses to test itself against a variety of data. 

Tau's **Death Tests** can be found in [Random](Random). Here, a Python script generates a bunch of random data, from strings to integers to floats, and in each case, Tau is tested for its grit. Around 7000 tests *per scenario* are run.
