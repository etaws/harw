# Tau's Benchmarks

Each of the assertions that Tau provides is blazing fast. I've tested them hundreds of times on old laptops I've
found around the house and each takes ~1-2us to complete. 

I'm currently working on a benchmark script to plot results and compare them with Googletest, Catch2, and other 
unit testing libraries - if you'd like to join in on the fun, do pull up a PR and we can discuss from there :)
